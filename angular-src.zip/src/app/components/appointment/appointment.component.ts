import { Component, OnInit } from '@angular/core';
import { Task } from './../../../../../models/Task';
import { TaskService } from './../../services/task.service';
import { AuthService } from './../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.css']
})
export class AppointmentComponent implements OnInit {
  tasks: Task[]
  task_name: string
  task_info: string
  task_userId: string
  task_label: string;
  task_type: string;
  task_duedate: string;
  task_time: string;
  task_isDone: boolean;
  color_choose: string;
    
  editState: boolean = false;
  taskToEdit: Task;

  
  constructor(private taskService:TaskService, private authService:AuthService) {
    this.taskService.getAppointment().subscribe(tasks=>{this.tasks=tasks});
   }

  ngOnInit(): void {
    this.authService.getProfile().subscribe(profile => {
      // this.user = profile['user'];
      this.task_userId=profile['user']._id
    },
     err => {
       console.log(err);
       return false;
     });
  
  }

  addTask(event){
    event.preventDefault();
    console.log(this.task_name);
    console.log(this.task_userId);
    var newTask={
      task_userId: this.task_userId,
      task_name: this.task_name,
      task_info: this.task_info,
      task_type: "appointment",
      task_duedate: this.task_duedate,
      task_time: this.task_time,
      task_label: this.task_label,
      task_isDone: false
    }
    this.taskService.addAppointment(newTask)
    .subscribe(task=> {
      this.tasks.push(task)
      this.task_info='';
      this.task_name ='';
      this.task_time='';
      this.task_duedate ='';
      this.task_label='';
  })
 }

 deleteTask(id){
   this.clearState();
  var tasks = this.tasks;
  
  this.taskService.deleteTask(id).subscribe(data => {
      if(data.n == 1){
          for(var i = 0;i < tasks.length;i++){
              if(tasks[i]._id == id){
                  tasks.splice(i, 1);
              }
          }
      }
  });
}

editTask(event, task: Task){
  this.editState = true;
  this.taskToEdit = task;
}

updateDone(task){
  console.log("updating",task)
  var _task = {
      _id:task._id,
      task_isDone: !task.task_isDone
  };
  
  this.taskService.updateAppointment(_task).subscribe(data => {
      task.task_isDone= !task.task_isDone; 
  });

}
updateStatus(task){
  console.log("updating",task)
  var _task = {
      _id:task._id,
      task_userId: task.userId,
      task_name: task.task_name,
      task_info: task.task_info,
      task_duedate: task.task_duedate,
      task_time: task.task_time,
      task_label: task.task_label,
      task_isDone: task.task_isDone
  };
  
  this.taskService.updateAppointment(_task).subscribe(data => {
      task.task_name = _task.task_name;
      task.task_info = _task.task_info;
      task.task_duedate= task.task_duedate;
      task.task_time= task.task_time;
      task.task_label= task.task_label;
      task.task_isDone= task.task_isDone; 
  });
  console.log("new data", _task);
  this.clearState()
}
clearState(){
  this.editState = false;
  this.taskToEdit = null;
}


}
