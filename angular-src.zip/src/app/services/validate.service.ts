import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class ValidateService {
  validateRegister(user){
    if(user.name == undefined || user.phone == undefined || user.username == undefined || user.password == undefined) {
      return false;
  } else {
    return true;
  }

  }

  constructor() { }
}
